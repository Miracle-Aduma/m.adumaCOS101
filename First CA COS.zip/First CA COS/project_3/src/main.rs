//Rust program to manage simple purchase orders


use std::io;

fn main() {
    //The menu
    println!("This is the menu (Code..Item..Price(N))
        1. L..Laptop..550000
        2. M..Monitor..120000
        3. K..Keyboard..15000
        4. H..Headset..25000");


    //Entering item code and quantity

    let L = laptop;
    let M = monitor;
    let K = keyboard;
    let H = headset;

    let L = 550000


    println!("\nEnter the item code:");
    io::stdin().read_line(&mut input).expect("Failed to read input");
    println!("Your item is: {}", code);


    //Entering quantity
    println!("\nEnter the quantity:");
    io::stdin().read_line(&mut input).expect("Not a valid string");
    let quantity:f32 = input.trim().parse().expect("Not a valid number");

    //Total cost
    let mut input1 = String::new();

    //Discount application
    if total cost > 500000.0
        {

        }
}
